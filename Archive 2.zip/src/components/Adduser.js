import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'
import axios from "axios"
const Adduser = () => {
    let navigate = useNavigate();
    const [user, setUser] = useState({
        index: " ",
        name: " ",
        email: " ",
        role: " "
    })
    const onInputChange = e => {
        setUser({ ...user, [e.target.id]: e.target.value })
        console.log(user)

    };
    const onSubmit = async e => {
        e.preventDefault();
        await axios.post("http://localhost:3001/users", user);
        navigate("/")
    }
    return (
        <div className="container">
            <div className="w-75 mx-auto shadow p-5">
                <h2 className="text-center mb-4">Add A User</h2>
                <form onSubmit={e => onSubmit(e)}>


                    <div className="mb-3">
                        <label htmlFor="name" className="form-label">Name</label>
                        <input type="text" onChange={e => onInputChange(e)} className="form-control" value={user.name} id="name" />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="email" className="form-label">Email address</label>
                        <input type="email" onChange={e => onInputChange(e)} className="form-control" id="email" value={user.email} aria-describedby="emailHelp" />
                        <div id="emailHelp" className="form-text">We'll never share your email with anyone else.</div>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="role" className="form-label">Role</label>
                        <input type="text" onChange={e => onInputChange(e)} className="form-control" value={user.role} id="role" />
                    </div>

                    <button type="submit" className="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>

    )
}
export default Adduser