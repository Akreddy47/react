import react from "react";
const Alumni = () => {
    return (
        <h1>This is alumni Page</h1>
    )
}

export default Alumni;