import React, { useState, useRef, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios"
import Pagination from "./Pagination";

const Home = () => {
    const [users, setUsers] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [usersPerPage] = useState(10);
    const [searchTerm, setSearchTerm] = useState("");
    const [newUsers, setNewUsers] = useState([]);
    const input = useRef("");
    useEffect(() => {
        loadUsers();
    }, []);

    const loadUsers = async () => {
        const result = await axios.get("http://localhost:3001/users");
        setUsers(result.data.reverse());
        setNewUsers(result.data.reverse());
    };
    const deleteUser = async id => {
        await axios.delete(`http://localhost:3001/users/${id}`);
        loadUsers();
    }
    const indexOfLastPost = currentPage * usersPerPage;
    const indexOfFirstPost = indexOfLastPost - usersPerPage;
    var currentUsers = newUsers.slice(indexOfFirstPost, indexOfLastPost);

    // Change page
    const paginate = pageNumber => setCurrentPage(pageNumber);

    //search
    const search = (searchTerm, e) => {

        e.preventDefault();

        if (searchTerm.toString() !== "") {
            const newUser = users.filter(user => {
                return Object.values(user).join(" ").toLowerCase().includes(searchTerm.toString().toLowerCase());
            });
            console.log(searchTerm);
            setNewUsers(newUser);
            console.log(newUser);
        }
        else {
            setNewUsers(users);
        }


    }
    const searchValue = e => {
        setSearchTerm([input.current.value]);
        console.log(users);
        console.log(searchTerm);

    }

    return (

        <div className="container">
            <div className="py-4">
                <h1>Home Page</h1>

                <form className="d-flex">
                    <input ref={input} className="form-control me-2" type="search" placeholder="Search by name or email" onChange={e => searchValue(e)} aria-label="Search" />
                    <button className="btn btn-outline-success" onClick={(e) => search(searchTerm, e)} type="submit">Search</button>
                </form>
                <table className="table border shadow">
                    <thead className="thead-dark">
                        <tr>
                            <th scope="col">S.No</th>
                            <th scope="col">Name</th>

                            <th scope="col">Email</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>

                        {currentUsers.map((user, index) => (
                            <tr>
                                <th scope="row">{index + 1}

                                </th>

                                <td>{user.name}</td>

                                <td>{user.email}</td>

                                <td>

                                    <Link
                                        className="btn btn-outline-primary"
                                        to={`/edit/${user.id}`}
                                    >
                                        Edit
                                    </Link>
                                    <Link
                                        className="btn btn-danger"
                                        onClick={() => { deleteUser(user.id) }}
                                        to="/"

                                    >
                                        Delete
                                    </Link>
                                </td>
                            </tr>))}




                    </tbody>
                </table>

                <Pagination usersPerPage={usersPerPage} totalUsers={newUsers.length} paginate={paginate} />

            </div>
        </div>


    )
}
export default Home;