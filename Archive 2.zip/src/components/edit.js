import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios"
const Edit = () => {
    const { id } = useParams();
    let navigate = useNavigate();
    const [user, setUser] = useState({
        index: " ",
        name: " ",
        email: " ",
        role: " "
    })
    useEffect(() => {
        loadUser();
    }, [])
    const loadUser = async () => {
        const result = await axios.get(`http://localhost:3001/users/${id}`)
        setUser(result.data);

    }
    const onInputChange = e => {
        setUser({ ...user, [e.target.id]: e.target.value })

    };
    const onSubmit = async e => {
        e.preventDefault();
        await axios.put(`http://localhost:3001/users/${id}`, user);
        navigate("/")
    }
    return (
        <form onSubmit={e => onSubmit(e)}>


            <div className="mb-3">
                <label htmlFor="name" className="form-label">Name</label>
                <input type="text" onChange={e => onInputChange(e)} className="form-control" value={user.name} id="name" />
            </div>
            <div className="mb-3">
                <label htmlFor="email" className="form-label">Email address</label>
                <input type="email" onChange={e => onInputChange(e)} className="form-control" id="email" value={user.email} aria-describedby="emailHelp" />
                <div id="emailHelp" className="form-text">We'll never share your email with anyone else.</div>
            </div>
            <div className="mb-3">
                <label htmlFor="role" className="form-label">Role</label>
                <input type="text" onChange={e => onInputChange(e)} className="form-control" value={user.role} id="role" />
            </div>

            <button type="submit" className="btn btn-primary">Submit</button>
        </form>

    )
}
export default Edit;