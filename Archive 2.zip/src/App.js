import './App.css';
import React from 'react';
import "../node_modules/bootstrap/dist/css/bootstrap.css";
import Home from "./components/home"
import Alumni from "./components/Alumni"
import Navbar from "./components/navbar"
import Adduser from "./components/Adduser"
import Edit from "./components/edit"
import {
  BrowserRouter as Router,
  Route,
  Routes

} from "react-router-dom";
function App(props) {
  return (
    <Router>
      <div className="App">

        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/alumni" element={<Alumni />} />
          <Route path="/adduser" element={<Adduser />} />
          <Route path="/edit/:id" element={<Edit />} />
        </Routes>



      </div>
    </Router>
  );
}

export default App;
